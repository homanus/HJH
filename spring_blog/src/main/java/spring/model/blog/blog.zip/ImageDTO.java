package spring.model.blog;

import org.springframework.web.multipart.MultipartFile;

public class ImageDTO {
	
	private int ino;
	private String title;
	private String fname;
	private String content;
	private String passwd;
	private String mname;
	private String wdate;
	private MultipartFile fnameMF;

	
	
	
	

	public int getIno() {
		return ino;
	}
	
	public void setIno(int ino) {
		this.ino = ino;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getWdate() {
		return wdate;
	}

	public void setWdate(String wdate) {
		this.wdate = wdate;
	}

	public MultipartFile getFnameMF() {
		return fnameMF;
	}

	public void setFnameMF(MultipartFile fnameMF) {
		this.fnameMF = fnameMF;
	}

}
